export default function Platform() {
  return (
    <main style={{ padding: 40 }}>
      <h1>Platform Overview</h1>
      <p>Input → Context → Audit Modules → Output</p>
    </main>
  );
}
