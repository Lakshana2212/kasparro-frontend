export default function Home() {
  return (
    <main style={{ padding: 40 }}>
      <h1>Kasparro</h1>
      <p>AI-native SEO & Brand Intelligence for AI-first search.</p>
      <a href="/platform">Run AI-SEO Audit →</a>
    </main>
  );
}
