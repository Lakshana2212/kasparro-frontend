export default function AppLayout({ children }: { children: React.ReactNode }) {
  return (
    <div style={{ display: "flex" }}>
      <nav style={{ width: 200, padding: 20 }}>
        <a href="/app/dashboard">Dashboard</a><br/>
        <a href="/app/audit">Audit</a><br/>
        <a href="/app/architecture">Architecture</a>
      </nav>
      <main style={{ padding: 40, flex: 1 }}>{children}</main>
    </div>
  );
}
