import modules from "@/data/auditModules.json";

export default function Audit() {
  return (
    <div>
      <h1>Audit</h1>
      {modules.map(m => (
        <div key={m.id} style={{ marginBottom: 20 }}>
          <h3>{m.name} — {m.score}</h3>
          <ul>
            {m.insights.map((i: string) => <li key={i}>{i}</li>)}
          </ul>
        </div>
      ))}
    </div>
  );
}
