export default function Dashboard() {
  return (
    <div>
      <h1>Dashboard</h1>
      <ul>
        <li>AI Visibility: 72</li>
        <li>EEAT Score: 65</li>
        <li>Non-Branded Coverage: 58%</li>
      </ul>
    </div>
  );
}
