export default function Architecture() {
  return (
    <div>
      <h1>System Architecture</h1>
      <ul>
        <li>InputAssembler</li>
        <li>ContextPack</li>
        <li>Audit Modules</li>
        <li>Output Surfaces</li>
      </ul>
    </div>
  );
}
