export default function About() {
  return (
    <main style={{ padding: 40 }}>
      <h1>About</h1>
      <p>Built for the AI-first search era.</p>
    </main>
  );
}
